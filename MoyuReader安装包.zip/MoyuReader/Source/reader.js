ObjC.import('AppKit');
ObjC.import('Foundation');
ObjC.import('ApplicationServices');
ObjC.import('objc');

// Native AppKit UI, packaged with macOS's JavaScript for Automation runtime.
var ui = {}, controller, prefs = {}, currentTitle = '', currentPath = '';
var base = ObjC.unwrap($.NSHomeDirectory()) + '/Library/Application Support/MoyuReader';
var fm = $.NSFileManager.defaultManager;
var testing = false;
var globalKeyMonitor = null, globalKeyHandler = null;
var shortcutReady = false;
var chaptersEnabled = false, chapters = [];
var chapterCursor = null;
var searchState = { query: '', range: null };
var shortcutTestSink = null;
var activeColorSampler = null, colorSamplerHandler = null;
var typographyTimer = null, pendingTypography = null;
var liveResizeState = null;
var shortcutSettingsOpen = false;
var shortcutModifierChoices = [0x80000, 0xc0000, 0x180000, 0x120000, 0x60000, 0x100000, 0x40000, 0xa0000, 0x140000, 0x1a0000, 0xe0000, 0x1c0000, 0x160000, 0x1e0000];
var shortcutKeyChoices = [];
var letterCodes = { A:0, B:11, C:8, D:2, E:14, F:3, G:5, H:4, I:34, J:38, K:40, L:37, M:46, N:45, O:31, P:35, Q:12, R:15, S:1, T:17, U:32, V:9, W:13, X:7, Y:16, Z:6 };
Object.keys(letterCodes).sort().forEach(function(letter) { shortcutKeyChoices.push({ label: letter, code: letterCodes[letter], key: letter.toLowerCase() }); });
[29,18,19,20,21,23,22,26,28,25].forEach(function(code, digit) { shortcutKeyChoices.push({ label: String(digit), code: code, key: String(digit) }); });
[122,120,99,118,96,97,98,100,101,109,103,111].forEach(function(code, index) { shortcutKeyChoices.push({ label: 'F' + (index + 1), code: code, key: String.fromCharCode(0xf704 + index) }); });

function defaultShortcuts() { return { visibility: { keyCode: 6, modifiers: 0x80000 }, compact: { keyCode: 7, modifiers: 0x80000 } }; }
function shortcutKey(code) {
    for (var i = 0; i < shortcutKeyChoices.length; i++) if (shortcutKeyChoices[i].code === code) return shortcutKeyChoices[i];
    return null;
}
function modifierLabel(flags) {
    return ((flags & 0x40000) ? '⌃' : '') + ((flags & 0x80000) ? '⌥' : '') + ((flags & 0x20000) ? '⇧' : '') + ((flags & 0x100000) ? '⌘' : '');
}
function formatShortcut(binding) { var key = shortcutKey(binding.keyCode); return modifierLabel(binding.modifiers) + (key ? key.label : '?'); }
function validateShortcuts(value) {
    if (!value || typeof value !== 'object') return '请选择快捷键。';
    var actions = ['visibility', 'compact'];
    for (var i = 0; i < actions.length; i++) {
        var binding = value[actions[i]];
        if (!binding || !shortcutKey(binding.keyCode) || shortcutModifierChoices.indexOf(binding.modifiers) < 0)
            return '组合键必须包含 ⌘、⌃ 或 ⌥，并选择字母、数字或 F1–F12。';
        // Preserve the app's editing, search and existing menu commands.
        if ((binding.modifiers === 0x100000 && [0,8,3,5,4,31,35,12,17,9,7,6].indexOf(binding.keyCode) >= 0) ||
            (binding.modifiers === 0x120000 && binding.keyCode === 5)) return '这个组合键已用于本应用的编辑、搜索或菜单操作，请换一个。';
    }
    if (value.visibility.keyCode === value.compact.keyCode && value.visibility.modifiers === value.compact.modifiers)
        return '两个功能不能使用相同的快捷键。';
    return '';
}
function normalizeShortcuts(value) { return validateShortcuts(value) ? defaultShortcuts() : JSON.parse(JSON.stringify(value)); }
function updateShortcutUI() {
    var summary = formatShortcut(prefs.shortcuts.visibility) + ' 隐藏 / 恢复；' + formatShortcut(prefs.shortcuts.compact) + ' 收起 / 展开';
    ui.shortcut.title = '快捷键设置';
    ui.shortcut.toolTip = summary + (shortcutReady ? '（全局监听已开启）' : '（全局使用需辅助功能授权）');
    [['visibilityMenu', 'visibility'], ['compactMenu', 'compact']].forEach(function(pair) {
        if (ui[pair[0]]) {
            var binding = prefs.shortcuts[pair[1]];
            ui[pair[0]].keyEquivalent = shortcutKey(binding.keyCode).key;
            ui[pair[0]].keyEquivalentModifierMask = binding.modifiers;
        }
    });
    updateStatus();
}
function applyShortcutSettings(value) {
    var error = validateShortcuts(value);
    if (error) throw new Error(error);
    prefs.shortcuts = normalizeShortcuts(value);
    updateShortcutUI();
    save();
}
function shortcutSettingsForm(draft) {
    var view = $.NSView.alloc.initWithFrame($.NSMakeRect(0, 0, 360, 128));
    var rows = {};
    [['visibility', '隐藏 / 恢复'], ['compact', '收起 / 展开']].forEach(function(pair, row) {
        var y = 88 - row * 46;
        var name = $.NSTextField.labelWithString($(pair[1])); name.setFrame($.NSMakeRect(0, y + 3, 100, 22)); view.addSubview(name);
        var modifiers = $.NSPopUpButton.alloc.initWithFramePullsDown($.NSMakeRect(108, y, 134, 28), false);
        shortcutModifierChoices.forEach(function(flags) { modifiers.addItemWithTitle(modifierLabel(flags)); });
        modifiers.selectItemAtIndex(shortcutModifierChoices.indexOf(draft[pair[0]].modifiers));
        view.addSubview(modifiers);
        var key = $.NSPopUpButton.alloc.initWithFramePullsDown($.NSMakeRect(250, y, 100, 28), false);
        shortcutKeyChoices.forEach(function(choice) { key.addItemWithTitle(choice.label); });
        var selected = 0;
        shortcutKeyChoices.forEach(function(choice, index) { if (choice.code === draft[pair[0]].keyCode) selected = index; });
        key.selectItemAtIndex(selected); view.addSubview(key);
        rows[pair[0]] = { modifiers: modifiers, key: key };
    });
    var hint = $.NSTextField.labelWithString('修饰键 + 按键；请避开系统或其他应用已占用的组合。');
    hint.font = $.NSFont.systemFontOfSize(11); hint.setFrame($.NSMakeRect(0, 5, 360, 22)); view.addSubview(hint);
    return { view: view, rows: rows };
}
function readShortcutForm(form) {
    var result = {};
    ['visibility', 'compact'].forEach(function(action) {
        var row = form.rows[action];
        result[action] = { keyCode: shortcutKeyChoices[Number(row.key.indexOfSelectedItem)].code, modifiers: shortcutModifierChoices[Number(row.modifiers.indexOfSelectedItem)] };
    });
    return result;
}
function openShortcutSettings() {
    if (shortcutSettingsOpen) return;
    var draft = normalizeShortcuts(prefs.shortcuts), error = '';
    shortcutSettingsOpen = true;
    try {
        while (true) {
            var dialog = $.NSAlert.alloc.init;
            dialog.messageText = '快捷键设置';
            dialog.informativeText = (error ? error + '\n\n' : '') + '保存后立即生效，并自动记住设置。\n全局使用需辅助功能授权；收起时也可从菜单或 ⌘, 打开设置。';
            var form = shortcutSettingsForm(draft); dialog.accessoryView = form.view;
            dialog.addButtonWithTitle('保存');
            var cancelButton = dialog.addButtonWithTitle('取消'); cancelButton.keyEquivalent = '\u001b';
            dialog.addButtonWithTitle('恢复默认'); dialog.addButtonWithTitle('全局授权');
            var response = Number(dialog.runModal);
            if (response === 1001) return;
            if (response === 1002) { draft = defaultShortcuts(); error = ''; continue; }
            draft = readShortcutForm(form);
            if (response === 1003) { enableShortcut(); continue; }
            if (response !== 1000) return;
            error = validateShortcuts(draft);
            if (!error) { applyShortcutSettings(draft); return; }
        }
    } finally { shortcutSettingsOpen = false; }
}

function compactLayout() {
    return !!prefs.compact || Number(ui.root.bounds.size.width) < 440 || Number(ui.root.bounds.size.height) < 456;
}
function restoreReadingAnchor(anchor, selection) {
    var length = Number(ui.text.textStorage.length);
    if (length) {
        var range = $.NSMakeRange(Math.max(0, Math.min(length - 1, anchor)), 1), manager = ui.text.layoutManager;
        manager.ensureLayoutForCharacterRange(range);
        var glyphs = manager.glyphRangeForCharacterRangeActualCharacterRange(range, null);
        var rect = manager.boundingRectForGlyphRangeInTextContainer(glyphs, ui.text.textContainer);
        var y = Math.max(0, Number(rect.origin.y) + Number(ui.text.textContainerOrigin.y));
        ui.scroll.contentView.scrollToPoint($.NSMakePoint(0, y));
        ui.scroll.reflectScrolledClipView(ui.scroll.contentView);
    }
    if (selection) ui.text.setSelectedRange(selection);
}
function beginWindowResize() {
    if (liveResizeState !== null) return;
    flushTypography();
    liveResizeState = { anchor: readingAnchor(), selection: ui.text.selectedRange, width: Number(ui.root.bounds.size.width), frozen: false, lastLayout: 0 };
}
function handleWindowResize() {
    if (liveResizeState !== null) {
        if (!liveResizeState.frozen && Math.abs(Number(ui.root.bounds.size.width) - liveResizeState.width) > 0.5) {
            // Keep the text container's original wrapping width during the drag.
            ui.text.textContainer.widthTracksTextView = false;
            ui.text.autoresizingMask = 0;
            liveResizeState.frozen = true;
        }
        var now = Date.now();
        if (now - liveResizeState.lastLayout < 33) return;
        liveResizeState.lastLayout = now;
    }
    layout();
}
function endWindowResize() {
    var state = liveResizeState;
    if (state === null) { layout(); return; }
    // Leave wrapping frozen while setting the final viewport and document size.
    layout();
    if (state.frozen) {
        var finalWidth = Number(ui.scroll.contentSize.width);
        ui.text.setFrameSize($.NSMakeSize(finalWidth, Number(ui.text.frame.size.height)));
        ui.text.textContainer.containerSize = $.NSMakeSize(Math.max(1, finalWidth - 2 * Number(ui.text.textContainerInset.width)), Number(ui.text.textContainer.containerSize.height));
        ui.text.autoresizingMask = 2;
        ui.text.textContainer.widthTracksTextView = true;
    }
    liveResizeState = null;
    restoreReadingAnchor(state.anchor, state.selection);
}
function expandWindowForControls() {
    var w = Number(ui.root.bounds.size.width), h = Number(ui.root.bounds.size.height);
    if (w >= 440 && h >= 456) return;
    var before = ui.window.frame;
    ui.window.setContentSize($.NSMakeSize(Math.max(480, w), Math.max(640, h)));
    var after = ui.window.frame;
    ui.window.setFrameOrigin($.NSMakePoint(Number(before.origin.x), Number(before.origin.y) + Number(before.size.height) - Number(after.size.height)));
}

function queueTypography() {
    if (pendingTypography === null) pendingTypography = { anchor: readingAnchor(), selection: ui.text.selectedRange };
    if (typographyTimer !== null) typographyTimer.invalidate;
    typographyTimer = $.NSTimer.scheduledTimerWithTimeIntervalTargetSelectorUserInfoRepeats(0.12, controller, 'flushTypography:', $(), false);
}
function flushTypography() {
    if (typographyTimer !== null) typographyTimer.invalidate;
    typographyTimer = null;
    var pending = pendingTypography;
    pendingTypography = null;
    if (pending !== null) applyTypography(pending.anchor, pending.selection);
}

function acceptSampledColor(color) {
    if (!color || color.isNil() || !Boolean(color.respondsToSelector('colorUsingColorSpace:'))) return;
    var hex = colorToHex(color);
    if (hex !== null) changeTextColor(hex);
}
function sampleTextColor() {
    if (activeColorSampler !== null) return;
    if (Boolean(ui.colorWell.active)) ui.colorWell.deactivate;
    $.NSColorPanel.sharedColorPanel.orderOut(null);
    activeColorSampler = $.NSColorSampler.alloc.init;
    ui.sampleColor.enabled = false;
    colorSamplerHandler = function(color) {
        activeColorSampler = null;
        ui.sampleColor.enabled = true;
        acceptSampledColor(color);
        colorSamplerHandler = null;
    };
    try { activeColorSampler.showSamplerWithSelectionHandler(colorSamplerHandler); }
    catch (e) {
        activeColorSampler = null; colorSamplerHandler = null;
        ui.sampleColor.enabled = true;
        alert('无法启动系统吸色器：' + String(e.message || e));
    }
}
function readingAnchor() {
    var length = Number(ui.text.textStorage.length);
    if (!length) return 0;
    var origin = ui.text.textContainerOrigin;
    var index = Number(ui.text.characterIndexForInsertionAtPoint($.NSMakePoint(Number(origin.x) + 2, Number(ui.scroll.contentView.bounds.origin.y) + 2)));
    return Math.max(0, Math.min(length - 1, index));
}
function applyTypography(anchor, selection) {
    var font = $.NSFont.systemFontOfSize(prefs.fontSize);
    var paragraph = ui.text.defaultParagraphStyle.mutableCopy;
    paragraph.lineSpacing = prefs.lineSpacing;
    paragraph.paragraphSpacing = prefs.fontSize * 0.65;
    var storage = ui.text.textStorage;
    storage.beginEditing;
    try {
        ui.text.font = font;
        ui.text.defaultParagraphStyle = paragraph;
        if (Number(storage.length)) storage.addAttributeValueRange($.NSParagraphStyleAttributeName, paragraph, $.NSMakeRange(0, Number(storage.length)));
    } finally { storage.endEditing; }
    var typing = ui.text.typingAttributes.mutableCopy;
    typing.setObjectForKey(font, $.NSFontAttributeName);
    typing.setObjectForKey(paragraph, $.NSParagraphStyleAttributeName);
    ui.text.typingAttributes = typing;
    ui.spacingValue.stringValue = prefs.lineSpacing + ' pt';
    ui.spacingSlider.doubleValue = prefs.lineSpacing;
    restoreReadingAnchor(anchor, selection);
    // Do not force a complete document layout or write settings per click.
}

function normalizeTextColor(value) {
    return typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value) ? value.toUpperCase() : null;
}
function readingColor() {
    var hex = normalizeTextColor(prefs.textColor);
    if (hex === null) return prefs.dark ? $.NSColor.whiteColor : $.NSColor.blackColor;
    return $.NSColor.colorWithSRGBRedGreenBlueAlpha(parseInt(hex.slice(1, 3), 16) / 255, parseInt(hex.slice(3, 5), 16) / 255, parseInt(hex.slice(5, 7), 16) / 255, 1);
}
function colorToHex(color) {
    var rgb = color.colorUsingColorSpace($.NSColorSpace.sRGBColorSpace);
    if (rgb.isNil()) return null;
    function hex(component) { return ('0' + Math.round(Math.max(0, Math.min(1, Number(component))) * 255).toString(16)).slice(-2); }
    return ('#' + hex(rgb.redComponent) + hex(rgb.greenComponent) + hex(rgb.blueComponent)).toUpperCase();
}
function updateColorControls() {
    ui.colorWell.color = readingColor();
    ui.colorValue.stringValue = prefs.textColor || '跟随背景';
    ui.colorWell.toolTip = prefs.textColor || '跟随背景';
}
function changeTextColor(value) {
    prefs.textColor = normalizeTextColor(value);
    var color = readingColor();
    // Only recolor glyphs; keep typography, selection and scroll unchanged.
    ui.text.textColor = color;
    var typing = ui.text.typingAttributes.mutableCopy;
    typing.setObjectForKey(color, $.NSForegroundColorAttributeName);
    ui.text.typingAttributes = typing;
    updateColorControls();
    save();
}
function chooseTextColor(sender) {
    var value = colorToHex(sender.color);
    if (value === null) { alert('请选择普通颜色作为字体颜色。'); return; }
    changeTextColor(value);
}

function recognizeChapters(text) {
    // Only stand-alone, short heading lines; indices use UTF-16 like NSRange.
    var pattern = /^[ \t\u3000]*(?:第[零〇一二三四五六七八九十百千万两壹贰叁肆伍陆柒捌玖拾佰仟0-9０-９]+[章回节卷部篇集][^\n]{0,100}|(?:chapter|part|book)[ \t]+(?:[0-9]+|[ivxlcdm]+)\b[^\n]{0,100}|(?:序章|楔子|序言|引子|前言|后记|尾声|终章|番外)[^\n]{0,60})[ \t\u3000]*$/gmi;
    var found = [], match;
    while ((match = pattern.exec(text)) !== null) {
        var title = match[0].trim();
        found.push({ title: title, index: match.index + match[0].indexOf(title), length: title.length });
    }
    return found;
}
function refreshChapters() {
    chapterCursor = null;
    chapters = chaptersEnabled ? recognizeChapters(ObjC.unwrap(ui.text.string)) : [];
    ui.chapterToggle.title = chaptersEnabled ? '识别目录：开' : '识别目录：关';
    ui.chapterList.removeAllItems;
    ui.chapterList.addItemWithTitle(chaptersEnabled ? (chapters.length ? '已识别 ' + chapters.length + ' 章 · 选择跳转' : '未找到规范章节标题') : '手动开启后识别章节目录');
    for (var i = 0; i < chapters.length; i++)
        ui.chapterList.addItemWithTitle((i + 1) + '. ' + chapters[i].title);
    ui.chapterList.enabled = chaptersEnabled && chapters.length > 0;
}
function toggleChapters() { chaptersEnabled = !chaptersEnabled; refreshChapters(); }
function jumpToRange(range, focus) {
    ui.text.setSelectedRange($.NSMakeRange(range.index, range.length));
    ui.text.scrollRangeToVisible($.NSMakeRange(range.index, range.length));
    if (focus) ui.window.makeFirstResponder(ui.text);
    updateStatus(); save();
}
function selectChapter() {
    var index = Number(ui.chapterList.indexOfSelectedItem) - 1;
    if (index >= 0 && index < chapters.length) jumpToChapter(index);
}
function chapterAtPosition(position) {
    var low = 0, high = chapters.length - 1, found = -1;
    while (low <= high) {
        var middle = Math.floor((low + high) / 2);
        if (chapters[middle].index <= position) { found = middle; low = middle + 1; }
        else high = middle - 1;
    }
    return found;
}
function jumpToChapter(index) {
    var chapter = chapters[index];
    if (!chapter) return;
    var range = $.NSMakeRange(chapter.index, chapter.length);
    restoreReadingAnchor(chapter.index, range);
    ui.chapterList.selectItemAtIndex(index + 1);
    ui.window.makeFirstResponder(ui.text);
    // Near the end of a book the last heading may not fit at the viewport top.
    // Remember explicit navigation until the user scrolls away from that point.
    chapterCursor = { index: index, y: Number(ui.scroll.contentView.bounds.origin.y) };
    updateStatus(); save();
}
function navigateChapter(direction) {
    if (!chaptersEnabled || !chapters.length) {
        ui.status.stringValue = chaptersEnabled ? '没有可切换的章节' : '请先手动开启「识别目录」，再用 ← / → 切换章节';
        return;
    }
    var y = Number(ui.scroll.contentView.bounds.origin.y);
    var current = chapterCursor !== null && Math.abs(y - chapterCursor.y) < 1 ? chapterCursor.index : chapterAtPosition(readingAnchor());
    var target = current + direction;
    if (target >= 0 && target < chapters.length) jumpToChapter(target);
}
function scrollReading(direction) {
    chapterCursor = null;
    var clip = ui.scroll.contentView;
    var maximum = Math.max(0, Number(ui.text.frame.size.height) - Number(clip.bounds.size.height));
    var step = Math.max(12, prefs.fontSize + prefs.lineSpacing);
    var y = Math.max(0, Math.min(maximum, Number(clip.bounds.origin.y) + direction * step));
    clip.scrollToPoint($.NSMakePoint(0, y));
    ui.scroll.reflectScrolledClipView(clip);
    updateStatus();
}
function dispatchReadingArrow(event) {
    var code = Number(event.keyCode);
    if (code < 123 || code > 126 || (Number(event.modifierFlags) & 0x1e0000) !== 0) return false;
    var responder = ui.window.firstResponder;
    if (!responder.isNil()) {
        // Text fields use a private NSTextView field editor. Leave its arrows,
        // and arrows on sliders and chapter menus, under native control.
        if ((Boolean(responder.isKindOfClass($.NSTextView)) && !Boolean(responder.isEqual(ui.text))) ||
            Boolean(responder.isKindOfClass($.NSTextField)) || Boolean(responder.isKindOfClass($.NSSlider)) ||
            Boolean(responder.isKindOfClass($.NSPopUpButton)) || Boolean(responder.isKindOfClass($.NSColorWell))) return false;
    }
    if (pendingTypography !== null) flushTypography();
    if (code === 126 || code === 125) scrollReading(code === 126 ? -1 : 1);
    else if (!Boolean(event.isARepeat)) navigateChapter(code === 123 ? -1 : 1);
    return true;
}
function locateText(text, query, start, direction) {
    if (!query.length || !text.length) return null;
    var nativeText = $(text), length = text.length;
    start = Math.max(0, Math.min(length, start));
    var options = $.NSCaseInsensitiveSearch | $.NSLiteralSearch | (direction < 0 ? $.NSBackwardsSearch : 0);
    var range = direction < 0 ? $.NSMakeRange(0, start) : $.NSMakeRange(start, length - start);
    var result = nativeText.rangeOfStringOptionsRange($(query), options, range);
    var wrapped = false;
    if (Number(result.location) > length) {
        wrapped = true;
        result = nativeText.rangeOfStringOptionsRange($(query), options, $.NSMakeRange(0, length));
    }
    if (Number(result.location) > length) return null;
    return { index: Number(result.location), length: Number(result.length), wrapped: wrapped };
}
function searchText(direction) {
    var query = ObjC.unwrap(ui.search.stringValue), text = ObjC.unwrap(ui.text.string);
    if (!query.length) {
        searchState = { query: '', range: null };
        ui.searchResult.stringValue = '输入关键词';
        return;
    }
    var same = query === searchState.query && searchState.range !== null;
    var start = same ? (direction < 0 ? searchState.range.index : searchState.range.index + searchState.range.length) : (direction < 0 ? text.length : 0);
    var match = locateText(text, query, start, direction);
    searchState = { query: query, range: match };
    if (match === null) {
        ui.searchResult.stringValue = '未找到';
        ui.text.setSelectedRange($.NSMakeRange(Number(ui.text.selectedRange.location), 0));
        return;
    }
    ui.searchResult.stringValue = match.wrapped ? '已循环定位' : '已定位';
    jumpToRange(match, false);
}
function focusSearch() {
    if (compactLayout()) toggleCompact();
    ui.window.makeFirstResponder(ui.search);
    ui.search.selectText(null);
}
function changeLineSpacing(value) {
    var anchor = testing ? readingAnchor() : 0, selection = testing ? ui.text.selectedRange : null;
    prefs.lineSpacing = Math.max(0, Math.min(40, Math.round(value)));
    if (testing) applyTypography(anchor, selection);
    else queueTypography();
}

function shortcutAction(event) {
    var flags = Number(event.modifierFlags) & 0x1e0000;
    var keys = prefs.shortcuts || defaultShortcuts();
    if (Number(event.keyCode) === keys.visibility.keyCode && flags === keys.visibility.modifiers) return 'visibility';
    if (Number(event.keyCode) === keys.compact.keyCode && flags === keys.compact.modifiers) return 'compact';
    return '';
}
function isToggleShortcut(event) {
    return shortcutAction(event) === 'visibility' && !Boolean(event.isARepeat);
}
function dispatchShortcut(event, perform) {
    if (shortcutSettingsOpen) return false;
    var action = shortcutAction(event);
    if (!action) return false;
    if (!Boolean(event.isARepeat)) {
        if (!perform && testing && shortcutTestSink) perform = shortcutTestSink;
        if (perform) perform(action);
        else if (action === 'visibility') toggleReader();
        else toggleCompact();
    }
    return true;
}
function toggleCompact() {
    var anchor = readingAnchor(), selection = ui.text.selectedRange;
    prefs.compact = !compactLayout();
    if (!prefs.compact) expandWindowForControls();
    if (prefs.compact && Boolean(ui.colorWell.active)) {
        ui.colorWell.deactivate;
        $.NSColorPanel.sharedColorPanel.orderOut(null);
    }
    layout();
    restoreReadingAnchor(anchor, selection);
    save();
}
function toggleReader() {
    var app = $.NSApplication.sharedApplication;
    if (Boolean(ui.window.visible) && !Boolean(app.hidden) && !Boolean(ui.window.miniaturized)) {
        save();
        app.hide(null);
    } else {
        app.unhide(null);
        if (Boolean(ui.window.miniaturized)) ui.window.deminiaturize(null);
        ui.window.makeKeyAndOrderFront(null);
        app.activateIgnoringOtherApps(true);
        ui.window.makeFirstResponder(ui.text);
    }
}
function refreshShortcut() {
    if (testing) return;
    var trusted = Boolean($.AXIsProcessTrusted());
    if (!trusted && globalKeyMonitor !== null) {
        $.NSEvent.removeMonitor(globalKeyMonitor);
        globalKeyMonitor = null;
        globalKeyHandler = null;
    }
    if (trusted && globalKeyMonitor === null) {
        globalKeyHandler = function(event) { dispatchShortcut(event); };
        var monitor = $.NSEvent.addGlobalMonitorForEventsMatchingMaskHandler(1 << 10, globalKeyHandler);
        if (!monitor.isNil()) globalKeyMonitor = monitor;
    }
    shortcutReady = trusted && globalKeyMonitor !== null;
    ui.shortcut.toolTip = formatShortcut(prefs.shortcuts.visibility) + ' 隐藏 / 恢复；' + formatShortcut(prefs.shortcuts.compact) + ' 收起 / 展开' + (shortcutReady ? '（全局已授权）' : '（全局待授权）');
}
function enableShortcut() {
    refreshShortcut();
    if (shortcutReady) {
        alert('全局快捷键\n\n' + formatShortcut(prefs.shortcuts.visibility) + '：隐藏 / 恢复\n' + formatShortcut(prefs.shortcuts.compact) + '：收起 / 展开\n\n阅读器需保持运行。');
        return;
    }
    var options = $.NSMutableDictionary.dictionary;
    options.setObjectForKey($.NSNumber.numberWithBool(true), $('AXTrustedCheckOptionPrompt'));
    $.AXIsProcessTrustedWithOptions(options);
    alert('阅读器内的自定义快捷键无需授权即可使用。\n\n若要在其他应用里使用，请在「系统设置 → 隐私与安全性 → 辅助功能」中允许当前版本的「摸鱼阅读」。\n\n升级后如仍无反应，请移除旧条目、重新添加当前应用，然后退出并重新打开。授权状态可在快捷键设置按钮的提示中查看。');
    refreshShortcut();
}

function stringAt(path) {
    var s = $.NSString.stringWithContentsOfFileEncodingError($(path), $.NSUTF8StringEncoding, null);
    return s.isNil() ? null : ObjC.unwrap(s);
}
function writeText(text, path) {
    if (!$(text).writeToFileAtomicallyEncodingError($(path), true, $.NSUTF8StringEncoding, null))
        throw new Error('无法保存文件：' + path);
}
function loadPrefs() {
    try { prefs = JSON.parse(stringAt(base + '/settings.json') || '{}'); } catch (_) { prefs = {}; }
    prefs.opacity = typeof prefs.opacity === 'number' ? Math.max(0, Math.min(1, prefs.opacity)) : 0.78;
    prefs.fontSize = Math.max(12, Math.min(32, Number(prefs.fontSize) || 18));
    prefs.lineSpacing = typeof prefs.lineSpacing === 'number' ? Math.max(0, Math.min(40, prefs.lineSpacing)) : Math.round(prefs.fontSize * 0.5);
    prefs.textColor = normalizeTextColor(prefs.textColor);
    prefs.shortcuts = normalizeShortcuts(prefs.shortcuts);
    prefs.dark = prefs.dark !== false;
    prefs.pinned = prefs.pinned !== false;
    prefs.progress = prefs.progress || {};
}
function progress() {
    var height = Number(ui.text.frame.size.height) - Number(ui.scroll.contentView.bounds.size.height);
    return height > 0 ? Math.max(0, Math.min(1, Number(ui.scroll.contentView.bounds.origin.y) / height)) : 0;
}
function save() {
    if (testing || !ui.text) return;
    if (currentPath) prefs.progress[currentPath] = progress();
    prefs.lastTitle = currentTitle;
    prefs.lastPath = currentPath;
    try { writeText(JSON.stringify(prefs), base + '/settings.json'); } catch (_) {}
    updateStatus();
}
function restoreProgress(value) {
    ui.text.layoutManager.ensureLayoutForTextContainer(ui.text.textContainer);
    var height = Math.max(0, Number(ui.text.frame.size.height) - Number(ui.scroll.contentView.bounds.size.height));
    ui.scroll.contentView.scrollToPoint($.NSMakePoint(0, height * Math.max(0, Math.min(1, value || 0))));
    ui.scroll.reflectScrolledClipView(ui.scroll.contentView);
}
function updateStatus() {
    var title = currentTitle ? currentTitle + '  ·  ' + Math.round(progress() * 100) + '%' : 'TXT 本地阅读';
    var keys = prefs.shortcuts || defaultShortcuts();
    ui.status.stringValue = title + '  ·  ' + formatShortcut(keys.visibility) + ' / ' + formatShortcut(keys.compact) + (shortcutReady ? '' : ' · 全局待授权');
}
function alert(message) {
    var box = $.NSAlert.alloc.init;
    box.messageText = '摸鱼阅读';
    box.informativeText = message;
    box.addButtonWithTitle('知道了');
    box.runModal;
}
function decode(data) {
    // BOM-aware Unicode first, then strict UTF-8 and common Chinese encodings.
    var bytes = ObjC.unwrap(data.base64EncodedStringWithOptions(0));
    var encodings = bytes.indexOf('//4') === 0 || bytes.indexOf('/v8') === 0 ? [$.NSUTF16StringEncoding] : [];
    encodings.push($.NSUTF8StringEncoding, 0x80000632); // CF GB18030 -> NSStringEncoding
    for (var i = 0; i < encodings.length; i++) {
        var decoded = $.NSString.alloc.initWithDataEncoding(data, encodings[i]);
        if (!decoded.isNil()) return ObjC.unwrap(decoded).replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
    }
    throw new Error('无法识别文本编码，请先将 TXT 转换为 UTF-8。');
}
function showBook(text, title, path, position) {
    ui.text.string = text;
    currentTitle = title;
    currentPath = path;
    ui.heading.stringValue = '摸鱼阅读';
    // Each book starts with recognition off; opening a file never scans implicitly.
    chaptersEnabled = false;
    refreshChapters();
    searchState = { query: '', range: null };
    ui.search.stringValue = '';
    ui.searchResult.stringValue = '输入关键词';
    applyStyle();
    restoreProgress(position);
    updateStatus();
}
function importBook() {
    var panel = $.NSOpenPanel.openPanel;
    panel.title = '选择一本 TXT 小说';
    panel.canChooseDirectories = false;
    panel.allowsMultipleSelection = false;
    panel.allowedFileTypes = ['txt'];
    if (Number(panel.runModal) !== 1) return;
    var path = ObjC.unwrap(panel.URL.path);
    try {
        var attrs = fm.attributesOfItemAtPathError($(path), null);
        if (Number(attrs.objectForKey($.NSFileSize)) > 30 * 1024 * 1024)
            throw new Error('请导入 30 MB 以内的 TXT 文件。');
        var data = $.NSData.dataWithContentsOfFile($(path));
        if (data.isNil()) throw new Error('无法读取这个文件。');
        var text = decode(data);
        save();
        // Cache before changing the screen, so failed imports preserve the current book.
        writeText(text, base + '/current.txt');
        var title = ObjC.unwrap($(path).lastPathComponent.stringByDeletingPathExtension);
        showBook(text, title, path, prefs.progress[path] || 0);
        save();
    } catch (e) { alert(String(e.message || e)); }
}
function label(text, size) {
    var view = $.NSTextField.labelWithString($(text));
    view.font = $.NSFont.systemFontOfSize(size);
    view.lineBreakMode = 4;
    ui.root.addSubview(view);
    return view;
}
function button(title, action) {
    var view = $.NSButton.buttonWithTitleTargetAction($(title), controller, action);
    view.bezelStyle = 1;
    ui.root.addSubview(view);
    return view;
}
function frame(view, x, y, w, h) { view.setFrame($.NSMakeRect(x, y, w, h)); }
function layout() {
    if (!ui.scroll) return;
    var w = Number(ui.root.bounds.size.width), h = Number(ui.root.bounds.size.height);
    var compact = compactLayout();
    if (!compact) {
    frame(ui.heading, 20, h - 66, 100, 26);
    frame(ui.author, 116, h - 62, 90, 20);
    frame(ui.shortcut, w - 214, h - 66, 128, 26);
    frame(ui.compact, w - 82, h - 66, 64, 26);
    frame(ui.open, 18, h - 105, 88, 28);
    frame(ui.pin, 112, h - 105, 92, 28);
    frame(ui.theme, 210, h - 105, 86, 28);
    frame(ui.smaller, w - 116, h - 105, 44, 28);
    frame(ui.larger, w - 66, h - 105, 48, 28);
    frame(ui.opacityLabel, 22, h - 142, 58, 22);
    frame(ui.slider, 82, h - 142, w - 165, 24);
    frame(ui.opacityValue, w - 74, h - 142, 58, 22);
    frame(ui.chapterToggle, 18, h - 179, 118, 28);
    frame(ui.chapterList, 142, h - 179, w - 160, 28);
    frame(ui.spacingLabel, 22, h - 215, 58, 22);
    frame(ui.spacingSlider, 82, h - 215, w - 165, 24);
    frame(ui.spacingValue, w - 74, h - 215, 58, 22);
    frame(ui.colorLabel, 22, h - 253, 58, 22);
    frame(ui.colorWell, 82, h - 253, 40, 26);
    frame(ui.colorBlack, 130, h - 253, 56, 26);
    frame(ui.colorWhite, 192, h - 253, 56, 26);
    frame(ui.colorAuto, 254, h - 253, 76, 26);
    frame(ui.sampleColor, 338, h - 253, w - 356, 26);
    frame(ui.search, 18, h - 289, w - 238, 26);
    frame(ui.searchPrev, w - 214, h - 289, 54, 26);
    frame(ui.searchNext, w - 154, h - 289, 54, 26);
    frame(ui.searchResult, w - 96, h - 286, 78, 20);
    }
    [ui.heading, ui.author, ui.shortcut, ui.status, ui.open, ui.pin, ui.theme, ui.smaller, ui.larger, ui.opacityLabel, ui.slider, ui.opacityValue, ui.chapterToggle, ui.chapterList, ui.spacingLabel, ui.spacingSlider, ui.spacingValue, ui.colorLabel, ui.colorWell, ui.colorBlack, ui.colorWhite, ui.colorAuto, ui.sampleColor, ui.search, ui.searchPrev, ui.searchNext, ui.searchResult].forEach(function(v) { v.hidden = compact; });
    ui.colorValue.hidden = true;
    ui.compact.title = compact ? '展开' : '收起';
    if (compact) frame(ui.compact, w - 82, h - 32, 64, 24);
    frame(ui.scroll, 12, compact ? 8 : 36, w - 24, Math.max(50, h - (compact ? 48 : 338)));
    frame(ui.status, 22, 10, w - 44, 20);
    // A height-only resize changes the viewport, not the document's layout.
    if (liveResizeState === null || !liveResizeState.frozen) {
        var textWidth = Number(ui.scroll.contentSize.width);
        if (Math.abs(Number(ui.text.frame.size.width) - textWidth) > 0.5)
            ui.text.setFrameSize($.NSMakeSize(textWidth, Number(ui.text.frame.size.height)));
    }
}
function applyOpacity() {
    // Slider tracking must not edit text storage, trigger full-book layout,
    // or write settings. The existing idle/quit saves persist the new value.
    ui.window.backgroundColor = $.NSColor.colorWithCalibratedWhiteAlpha(prefs.dark ? 0.07 : 0.98, prefs.opacity);
    ui.opacityValue.stringValue = Math.round(prefs.opacity * 100) + '%';
}
function changeOpacity(value) {
    prefs.opacity = Math.max(0, Math.min(1, value));
    applyOpacity();
}
function applyStyle() {
    var dark = prefs.dark;
    applyOpacity();
    ui.window.appearance = $.NSAppearance.appearanceNamed(dark ? 'NSAppearanceNameDarkAqua' : 'NSAppearanceNameAqua');
    ui.text.textColor = readingColor();
    ui.text.font = $.NSFont.systemFontOfSize(prefs.fontSize);
    var paragraph = $.NSMutableParagraphStyle.alloc.init;
    paragraph.lineSpacing = prefs.lineSpacing;
    paragraph.paragraphSpacing = prefs.fontSize * 0.65;
    ui.text.defaultParagraphStyle = paragraph;
    var attributes = $.NSMutableDictionary.dictionary;
    attributes.setObjectForKey(ui.text.font, $.NSFontAttributeName);
    attributes.setObjectForKey(ui.text.textColor, $.NSForegroundColorAttributeName);
    attributes.setObjectForKey(paragraph, $.NSParagraphStyleAttributeName);
    attributes.setObjectForKey($.NSNumber.numberWithDouble(0), $.NSStrokeWidthAttributeName);
    // Replace all attributes: no stroke, shadow, or background on any glyph.
    if (Number(ui.text.textStorage.length) > 0)
        ui.text.textStorage.setAttributesRange(attributes, $.NSMakeRange(0, Number(ui.text.textStorage.length)));
    ui.text.typingAttributes = attributes;
    var interfaceColor = dark ? $.NSColor.whiteColor : $.NSColor.blackColor;
    ui.heading.textColor = interfaceColor;
    ui.author.textColor = interfaceColor;
    ui.status.textColor = interfaceColor.colorWithAlphaComponent(0.65);
    ui.opacityLabel.textColor = ui.status.textColor;
    ui.opacityValue.textColor = ui.status.textColor;
    ui.spacingLabel.textColor = ui.status.textColor;
    ui.spacingValue.textColor = ui.status.textColor;
    ui.searchResult.textColor = interfaceColor;
    ui.colorLabel.textColor = ui.status.textColor;
    ui.colorValue.textColor = interfaceColor;
    updateColorControls();
    ui.spacingValue.stringValue = prefs.lineSpacing + ' pt';
    ui.spacingSlider.doubleValue = prefs.lineSpacing;
    ui.pin.title = prefs.pinned ? '置顶：开' : '置顶：关';
    ui.theme.title = dark ? '浅色背景' : '深色背景';
    ui.window.level = prefs.pinned ? 3 : 0;
    ui.window.invalidateShadow;
}
function changeFont(delta) {
    var next = Math.max(12, Math.min(32, prefs.fontSize + delta));
    if (next === prefs.fontSize) return;
    var anchor = testing ? readingAnchor() : 0, selection = testing ? ui.text.selectedRange : null;
    prefs.fontSize = next;
    if (testing) applyTypography(anchor, selection);
    else queueTypography();
}
ObjC.registerSubclass({
    name: 'MoyuReaderWindow',
    superclass: 'NSWindow',
    methods: {
        'sendEvent:': {
            types: ['void', ['id']],
            implementation: function(event) {
                if (!event || event.isNil()) return;
                // Option-only combinations can go directly to the focused view's
                // keyDown: without ever reaching performKeyEquivalent:.
                if (Number(event.type) === 10 && (dispatchShortcut(event) || dispatchReadingArrow(event))) return;
                this.moyuDefaultSendEvent(event);
            }
        },
        'performKeyEquivalent:': {
            types: ['bool', ['id']],
            implementation: function(event) {
                if (dispatchShortcut(event)) return true;
                var modifiers = Number(event.modifierFlags) & 0x1e0000;
                if (modifiers === 0x100000 && Number(event.keyCode) === 43) { openShortcutSettings(); return true; }
                if (modifiers === 0x100000 && Number(event.keyCode) === 3) { focusSearch(); return true; }
                if ((modifiers === 0x100000 || modifiers === 0x120000) && Number(event.keyCode) === 5) {
                    searchText(modifiers === 0x120000 ? -1 : 1); return true;
                }
                return false;
            }
        }
    }
});
// Keep the native implementation under a distinct selector. This avoids JXA's
// super-dispatch re-entering the override while forwarding ordinary events.
var defaultSendEventMethod = $.class_getInstanceMethod($.NSWindow, $.sel_registerName('sendEvent:'));
$.class_addMethod($.MoyuReaderWindow, $.sel_registerName('moyuDefaultSendEvent:'), $.method_getImplementation(defaultSendEventMethod), $.method_getTypeEncoding(defaultSendEventMethod));
ObjC.registerSubclass({
    name: 'MoyuReaderController',
    superclass: 'NSObject',
    protocols: ['NSWindowDelegate'],
    methods: {
        'openBook:': { types: ['void', ['id']], implementation: function() { importBook(); } },
        'opacityChanged:': { types: ['void', ['id']], implementation: function(sender) { changeOpacity(Number(sender.doubleValue)); } },
        'togglePin:': { types: ['void', ['id']], implementation: function() { prefs.pinned = !prefs.pinned; applyStyle(); save(); } },
        'toggleTheme:': { types: ['void', ['id']], implementation: function() { prefs.dark = !prefs.dark; applyStyle(); save(); } },
        'smaller:': { types: ['void', ['id']], implementation: function() { changeFont(-1); } },
        'larger:': { types: ['void', ['id']], implementation: function() { changeFont(1); } },
        'toggleChapters:': { types: ['void', ['id']], implementation: function() { toggleChapters(); } },
        'selectChapter:': { types: ['void', ['id']], implementation: function() { selectChapter(); } },
        'spacingChanged:': { types: ['void', ['id']], implementation: function(sender) { changeLineSpacing(Number(sender.doubleValue)); } },
        'textColorChanged:': { types: ['void', ['id']], implementation: function(sender) { chooseTextColor(sender); } },
        'blackText:': { types: ['void', ['id']], implementation: function() { changeTextColor('#000000'); } },
        'whiteText:': { types: ['void', ['id']], implementation: function() { changeTextColor('#FFFFFF'); } },
        'autoText:': { types: ['void', ['id']], implementation: function() { changeTextColor(null); } },
        'sampleTextColor:': { types: ['void', ['id']], implementation: function() { sampleTextColor(); } },
        'flushTypography:': { types: ['void', ['id']], implementation: function() { flushTypography(); } },
        'searchNext:': { types: ['void', ['id']], implementation: function() { searchText(1); } },
        'searchPrev:': { types: ['void', ['id']], implementation: function() { searchText(-1); } },
        'focusSearch:': { types: ['void', ['id']], implementation: function() { focusSearch(); } },
        'compact:': { types: ['void', ['id']], implementation: function() { toggleCompact(); } },
        'hideReader:': { types: ['void', ['id']], implementation: function() { save(); $.NSApplication.sharedApplication.hide(null); } },
        'toggleReader:': { types: ['void', ['id']], implementation: function() { toggleReader(); } },
        'enableShortcut:': { types: ['void', ['id']], implementation: function() { enableShortcut(); } },
        'openShortcutSettings:': { types: ['void', ['id']], implementation: function() { openShortcutSettings(); } },
        'quitReader:': { types: ['void', ['id']], implementation: function() { save(); $.NSApplication.sharedApplication.terminate(null); } },
        'windowWillStartLiveResize:': { types: ['void', ['id']], implementation: function() { beginWindowResize(); } },
        'windowDidResize:': { types: ['void', ['id']], implementation: function() { handleWindowResize(); } },
        'windowDidEndLiveResize:': { types: ['void', ['id']], implementation: function() { endWindowResize(); } },
        'windowWillClose:': { types: ['void', ['id']], implementation: function() { save(); $.NSApplication.sharedApplication.terminate(null); } }
    }
});
function menuItem(title, action, key) {
    var item = $.NSMenuItem.alloc.initWithTitleActionKeyEquivalent($(title), action, $(key));
    item.target = controller;
    return item;
}
function build() {
    var app = $.NSApplication.sharedApplication;
    app.setActivationPolicy(0);
    controller = $.MoyuReaderController.alloc.init;
    ui.window = $.MoyuReaderWindow.alloc.initWithContentRectStyleMaskBackingDefer($.NSMakeRect(0, 0, 480, 640), 1 | 2 | 4 | 8 | 32768, 2, false);
    ui.window.releasedWhenClosed = false;
    ui.window.title = '摸鱼阅读';
    ui.window.titleVisibility = 1;
    ui.window.titlebarAppearsTransparent = true;
    ui.window.opaque = false;
    // With transparent windows the window shadow can outline individual glyphs.
    ui.window.hasShadow = false;
    ui.window.minSize = $.NSMakeSize(260, 80);
    ui.window.collectionBehavior = 1 | 256;
    ui.root = ui.window.contentView;
    ui.heading = label('摸鱼阅读', 19);
    ui.heading.font = $.NSFont.boldSystemFontOfSize(19);
    ui.author = label('作者 yu1', 11);
    ui.open = button('导入 TXT', 'openBook:');
    ui.pin = button('置顶：开', 'togglePin:');
    ui.theme = button('浅色背景', 'toggleTheme:');
    ui.smaller = button('A−', 'smaller:');
    ui.larger = button('A+', 'larger:');
    ui.compact = button('收起', 'compact:');
    ui.shortcut = button('快捷键设置', 'openShortcutSettings:');
    ui.opacityLabel = label('背景', 12);
    ui.opacityValue = label('', 12);
    ui.slider = $.NSSlider.alloc.initWithFrame($.NSMakeRect(0, 0, 100, 24));
    ui.slider.minValue = 0; ui.slider.maxValue = 1; ui.slider.doubleValue = prefs.opacity;
    ui.slider.continuous = true; ui.slider.target = controller; ui.slider.action = 'opacityChanged:';
    ui.root.addSubview(ui.slider);
    ui.chapterToggle = button('识别目录：关', 'toggleChapters:');
    ui.chapterList = $.NSPopUpButton.alloc.initWithFramePullsDown($.NSMakeRect(0, 0, 100, 28), false);
    ui.chapterList.target = controller; ui.chapterList.action = 'selectChapter:';
    ui.root.addSubview(ui.chapterList);
    ui.spacingLabel = label('行间距', 12);
    ui.spacingValue = label('', 12);
    ui.spacingSlider = $.NSSlider.alloc.initWithFrame($.NSMakeRect(0, 0, 100, 24));
    ui.spacingSlider.minValue = 0; ui.spacingSlider.maxValue = 40;
    ui.spacingSlider.continuous = false;
    ui.spacingSlider.target = controller; ui.spacingSlider.action = 'spacingChanged:';
    ui.root.addSubview(ui.spacingSlider);
    ui.colorLabel = label('字体颜色', 12);
    ui.colorWell = $.NSColorWell.alloc.initWithFrame($.NSMakeRect(0, 0, 40, 26));
    ui.colorWell.target = controller; ui.colorWell.action = 'textColorChanged:';
    ui.colorWell.continuous = false;
    $.NSColorPanel.sharedColorPanel.continuous = false;
    $.NSColorPanel.sharedColorPanel.showsAlpha = false;
    ui.root.addSubview(ui.colorWell);
    ui.colorBlack = button('黑色', 'blackText:');
    ui.colorWhite = button('白色', 'whiteText:');
    ui.colorAuto = button('跟随背景', 'autoText:');
    ui.colorValue = label('跟随背景', 11);
    ui.sampleColor = button('吸色', 'sampleTextColor:');
    ui.sampleColor.toolTip = '拾取屏幕颜色作为字体颜色，按 Esc 取消';
    ui.search = $.NSSearchField.alloc.initWithFrame($.NSMakeRect(0, 0, 180, 26));
    ui.search.placeholderString = '搜索正文（⌘F）';
    ui.search.target = controller; ui.search.action = 'searchNext:';
    ui.search.sendsSearchStringImmediately = false;
    ui.search.sendsWholeSearchString = true;
    ui.root.addSubview(ui.search);
    ui.searchPrev = button('上一处', 'searchPrev:');
    ui.searchNext = button('下一处', 'searchNext:');
    ui.searchResult = label('输入关键词', 11);
    ui.scroll = $.NSScrollView.alloc.initWithFrame($.NSMakeRect(12, 36, 456, 446));
    ui.scroll.drawsBackground = false;
    ui.scroll.hasVerticalScroller = true;
    ui.scroll.autohidesScrollers = true;
    ui.scroll.borderType = 0;
    ui.text = $.NSTextView.alloc.initWithFrame($.NSMakeRect(0, 0, 456, 446));
    ui.text.editable = false;
    ui.text.selectable = true;
    ui.text.drawsBackground = false;
    ui.text.richText = false;
    ui.text.usesAdaptiveColorMappingForDarkAppearance = false;
    ui.text.verticallyResizable = true;
    ui.text.horizontallyResizable = false;
    ui.text.minSize = $.NSMakeSize(0, 0);
    ui.text.maxSize = $.NSMakeSize(10000000, 10000000);
    ui.text.autoresizingMask = 2;
    ui.text.textContainer.containerSize = $.NSMakeSize(456, 10000000);
    ui.text.textContainer.widthTracksTextView = true;
    ui.text.textContainerInset = $.NSMakeSize(12, 12);
    ui.scroll.documentView = ui.text;
    ui.root.addSubview(ui.scroll);
    ui.status = label('', 11);
    layout();
    ui.window.delegate = controller;
    var main = $.NSMenu.alloc.init;
    var root = $.NSMenuItem.alloc.init;
    var menu = $.NSMenu.alloc.initWithTitle('摸鱼阅读');
    menu.addItem(menuItem('导入 TXT…', 'openBook:', 'o'));
    menu.addItem(menuItem('搜索正文…', 'focusSearch:', 'f'));
    menu.addItem(menuItem('查找下一处', 'searchNext:', 'g'));
    var previousMatch = menuItem('查找上一处', 'searchPrev:', 'g');
    previousMatch.keyEquivalentModifierMask = 0x100000 | 0x20000;
    menu.addItem(previousMatch);
    menu.addItem(menuItem('收起 / 展开工具栏', 'compact:', 't'));
    menu.addItem(menuItem('置顶 / 取消置顶', 'togglePin:', 'p'));
    menu.addItem(menuItem('隐藏阅读器', 'hideReader:', 'h'));
    ui.visibilityMenu = menuItem('隐藏 / 恢复阅读器', 'toggleReader:', 'z');
    menu.addItem(ui.visibilityMenu);
    ui.compactMenu = menuItem('收起 / 展开阅读器', 'compact:', 'x');
    menu.addItem(ui.compactMenu);
    menu.addItem(menuItem('快捷键设置…', 'openShortcutSettings:', ','));
    menu.addItem(menuItem('启用全局快捷键…', 'enableShortcut:', ''));
    menu.addItem($.NSMenuItem.separatorItem);
    menu.addItem(menuItem('退出摸鱼阅读', 'quitReader:', 'q'));
    root.submenu = menu; main.addItem(root); app.mainMenu = main;
    updateShortcutUI();
    var cached = !testing && prefs.lastPath ? stringAt(base + '/current.txt') : null;
    if (cached !== null && cached !== false)
        showBook(cached, prefs.lastTitle, prefs.lastPath, prefs.progress[prefs.lastPath] || 0);
    else
        showBook('留一点时间，给故事。\n\n点击「导入 TXT」，打开你正在读的小说。\n\n拖动「背景」滑块，只改变背景透明度，文字仍保持清晰。0% 为全透明背景。\n\n文字支持自定义颜色、吸色和行距调整。可手动识别章节目录，用 ⌘F 搜索定位。拖动窗口顶部移动，拖动边缘改变大小。\n\n' + formatShortcut(prefs.shortcuts.visibility) + '　隐藏 / 恢复窗口\n' + formatShortcut(prefs.shortcuts.compact) + '　收起 / 展开\n⌘,　快捷键设置\n\n点击「快捷键设置」可以随时修改组合键。全局使用需在设置中点击「全局授权」，允许辅助功能。\n\n⌘O　导入小说\n⌘P　切换置顶\n⌘H　隐藏窗口\n⌘Q　保存并退出\n\n阅读进度会自动保存在本机，下次打开继续读。', '', '', 0);
    ui.window.center;
    if (!testing) {
        ui.window.setFrameAutosaveName('MoyuReaderWindow');
        ui.window.makeKeyAndOrderFront(null);
        app.activateIgnoringOtherApps(true);
        ui.window.makeFirstResponder(ui.text);
        refreshShortcut();
    }
}
function isSelfTestArguments(args) {
    // A Finder/app-launch run event may supply a null Apple Event descriptor,
    // rather than the JavaScript argument array supplied by osascript.
    // Never index a bridged descriptor: it can send `count` to NSNull.
    return Array.isArray(args) && args.length > 0 && args[0] === '--self-test';
}
function run(args) {
    testing = isSelfTestArguments(args);
    loadPrefs();
    if (testing) { prefs.textColor = null; prefs.shortcuts = defaultShortcuts(); }
    if (!testing && !fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError($(base), true, $.NSDictionary.dictionary, null)) {
        alert('无法创建本地阅读数据目录，请检查用户目录的写入权限。');
        return;
    }
    build();
    if (testing) {
        function assert(ok, description) { if (!ok) throw new Error(description); }
        assert(!isSelfTestArguments(undefined), 'Launch without arguments');
        assert(!isSelfTestArguments(null), 'Launch with null arguments');
        assert(!isSelfTestArguments($.NSNull.null), 'Launch with bridged null descriptor');
        assert(!isSelfTestArguments([]), 'Launch with empty argument array');
        assert(isSelfTestArguments(['--self-test']), 'Command-line test arguments');
        var testDir = ObjC.unwrap($.NSTemporaryDirectory()) + 'moyu-reader-startup-check';
        assert(Boolean(fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError($(testDir), true, $.NSDictionary.dictionary, null)), 'Create startup data directory');
        writeText('启动缓存检查', testDir + '/current.txt');
        assert(stringAt(testDir + '/current.txt') === '启动缓存检查', 'Write and read startup cache');
        fm.removeItemAtPathError($(testDir), null);
        var sample = '第一章\n你好，世界。';
        assert(decode($(sample).dataUsingEncoding($.NSUTF8StringEncoding)) === sample, 'UTF-8 decode');
        assert(decode($(sample).dataUsingEncoding(0x80000632)) === sample, 'GB18030 decode');
        assert(decode($(sample).dataUsingEncoding($.NSUTF16StringEncoding)) === sample, 'UTF-16 BOM decode');
        prefs.opacity = 0; applyStyle();
        assert(Number(ui.window.backgroundColor.alphaComponent) === 0, 'Transparent background');
        assert(Number(ui.text.textColor.alphaComponent) === 1, 'Opaque text');
        assert(!Boolean(ui.window.hasShadow), 'No window or glyph outline shadow');
        prefs.dark = true; applyStyle();
        assert(Boolean(ui.text.textColor.isEqual($.NSColor.whiteColor)), 'Pure white text');
        prefs.dark = false; applyStyle();
        assert(Boolean(ui.text.textColor.isEqual($.NSColor.blackColor)), 'Pure black text');
        var attrs = ui.text.textStorage.attributesAtIndexEffectiveRange(0, null);
        assert(Number(attrs.objectForKey($.NSStrokeWidthAttributeName).doubleValue) === 0, 'No glyph stroke');
        assert(attrs.objectForKey($.NSShadowAttributeName).isNil(), 'No glyph shadow');
        assert(isToggleShortcut({keyCode: 6, modifierFlags: 0x80000, isARepeat: false}), 'Option-Z exact match');
        assert(isToggleShortcut({keyCode: 6, modifierFlags: 0x90000, isARepeat: false}), 'Option-Z with caps lock');
        assert(!isToggleShortcut({keyCode: 6, modifierFlags: 0, isARepeat: false}), 'Ignore plain Z');
        assert(!isToggleShortcut({keyCode: 6, modifierFlags: 0x100000, isARepeat: false}), 'Ignore Cmd-Z');
        assert(!isToggleShortcut({keyCode: 6, modifierFlags: 0x180000, isARepeat: false}), 'Ignore Cmd-Option-Z');
        assert(!isToggleShortcut({keyCode: 46, modifierFlags: 0x180000, isARepeat: false}), 'Ignore previous shortcut');
        assert(!isToggleShortcut({keyCode: 6, modifierFlags: 0x80000, isARepeat: true}), 'Ignore held key repeats');
        assert(shortcutAction({keyCode: 7, modifierFlags: 0x80000}) === 'compact', 'Option-X compact shortcut');
        assert(shortcutAction({keyCode: 7, modifierFlags: 0x100000}) === '', 'Do not intercept Cmd-X');
        var actions = [];
        assert(dispatchShortcut({keyCode: 6, modifierFlags: 0x80000, isARepeat: false}, function(a) { actions.push(a); }), 'Consume local Option-Z');
        dispatchShortcut({keyCode: 7, modifierFlags: 0x80000, isARepeat: false}, function(a) { actions.push(a); });
        dispatchShortcut({keyCode: 7, modifierFlags: 0x80000, isARepeat: true}, function(a) { actions.push(a); });
        assert(actions.join(',') === 'visibility,compact', 'Dispatch both shortcuts exactly once');
        prefs.pinned = true; applyStyle(); assert(Number(ui.window.level) === 3, 'Floating window');
        prefs.pinned = false; applyStyle(); assert(Number(ui.window.level) === 0, 'Normal window');
        prefs.compact = true; layout(); assert(Boolean(ui.slider.hidden), 'Compact controls');
        assert(Boolean(ui.heading.hidden) && Boolean(ui.author.hidden) && Boolean(ui.shortcut.hidden) && Boolean(ui.status.hidden), 'Hide title, author and status when compact');
        prefs.compact = false; layout(); assert(!Boolean(ui.slider.hidden), 'Expanded controls');
        assert(!Boolean(ui.heading.hidden) && !Boolean(ui.author.hidden), 'Restore title and author when expanded');
        assert(ObjC.unwrap(ui.heading.stringValue) === '摸鱼阅读' && ObjC.unwrap(ui.author.stringValue) === '作者 yu1', 'Header credit');
        var event = $.NSEvent.keyEventWithTypeLocationModifierFlagsTimestampWindowNumberContextCharactersCharactersIgnoringModifiersIsARepeatKeyCode(10, $.NSMakePoint(0, 0), 0x80000, 0, Number(ui.window.windowNumber), $(), $('≈'), $('x'), false, 7);
        assert(Boolean(ui.window.performKeyEquivalent(event)), 'Native window consumes Option-X');
        assert(prefs.compact === true, 'Native local callback handles Option-X');
        ui.window.performKeyEquivalent(event);
        assert(prefs.compact === false, 'Native local callback expands on second Option-X');
        // Exercise the window's complete event route, not just key equivalents.
        ui.window.makeFirstResponder(ui.text);
        ui.window.sendEvent(event);
        assert(prefs.compact === true, 'Window sendEvent handles Option-X with body focused');
        ui.window.sendEvent(event);
        assert(prefs.compact === false, 'Window sendEvent expands on second Option-X');
        ui.window.makeFirstResponder(ui.search);
        ui.window.sendEvent(event);
        assert(prefs.compact === true, 'Option-X works while search field has focus');
        ui.window.sendEvent(event);
        assert(prefs.compact === false, 'Option-X restores tools from search focus');
        var visibilityCalls = 0;
        shortcutTestSink = function(action) { if (action === 'visibility') visibilityCalls++; };
        var visibilityEvent = $.NSEvent.keyEventWithTypeLocationModifierFlagsTimestampWindowNumberContextCharactersCharactersIgnoringModifiersIsARepeatKeyCode(10, $.NSMakePoint(0, 0), 0x80000, 0, Number(ui.window.windowNumber), $(), $('Ω'), $('z'), false, 6);
        ui.window.sendEvent(visibilityEvent);
        assert(visibilityCalls === 1, 'Window sendEvent dispatches Option-Z once');
        shortcutTestSink = null;
        var normalEvent = $.NSEvent.keyEventWithTypeLocationModifierFlagsTimestampWindowNumberContextCharactersCharactersIgnoringModifiersIsARepeatKeyCode(10, $.NSMakePoint(0, 0), 0, 0, Number(ui.window.windowNumber), $(), $('z'), $('z'), false, 6);
        ui.window.sendEvent(normalEvent);
        var callbackReceived = false;
        var center = $.NSNotificationCenter.defaultCenter;
        var observer = center.addObserverForNameObjectQueueUsingBlock($('MoyuReaderCallbackCheck'), $(), $(), function() { callbackReceived = true; });
        center.postNotificationNameObject($('MoyuReaderCallbackCheck'), $());
        center.removeObserver(observer);
        assert(callbackReceived, 'Native void callback actually invokes JavaScript');
        showBook(Array(300).join(sample + '\n'), '测试小说', '/test.txt', 0.5);
        assert(Math.abs(progress() - 0.5) < 0.03, 'Restore reading position');
        ui.text.setSelectedRange($.NSMakeRange(5, 2));
        var priorFont = Number(ui.text.font.pointSize), priorSpacing = Number(ui.text.defaultParagraphStyle.lineSpacing);
        ui.colorWell.color = $.NSColor.colorWithSRGBRedGreenBlueAlpha(0.2, 0.4, 0.6, 0.2);
        controller.textColorChanged(ui.colorWell);
        assert(prefs.textColor === '#336699' && colorToHex(ui.text.textColor) === '#336699', 'Native color well applies custom RGB color');
        assert(Number(ui.text.textColor.alphaComponent) === 1, 'Custom font color stays opaque');
        assert(Number(ui.text.font.pointSize) === priorFont && Number(ui.text.defaultParagraphStyle.lineSpacing) === priorSpacing, 'Recolor preserves font and line spacing');
        assert(Number(ui.text.selectedRange.location) === 5 && Number(ui.text.selectedRange.length) === 2 && Math.abs(progress() - 0.5) < 0.03, 'Recolor preserves selection and scroll');
        var customAttrs = ui.text.textStorage.attributesAtIndexEffectiveRange(5, null);
        assert(colorToHex(customAttrs.objectForKey($.NSForegroundColorAttributeName)) === '#336699', 'Custom color reaches stored glyph attributes');
        assert(Number(customAttrs.objectForKey($.NSStrokeWidthAttributeName).doubleValue) === 0 && customAttrs.objectForKey($.NSShadowAttributeName).isNil(), 'Recolor keeps no stroke or shadow');
        prefs.dark = !prefs.dark; applyStyle();
        assert(colorToHex(ui.text.textColor) === '#336699', 'Background switching preserves custom color');
        var originalBase = base, originalPrefs = prefs;
        var colorTestDir = ObjC.unwrap($.NSTemporaryDirectory()) + 'moyu-reader-color-check';
        fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError($(colorTestDir), true, $.NSDictionary.dictionary, null);
        try {
            writeText(JSON.stringify(prefs), colorTestDir + '/settings.json');
            base = colorTestDir; loadPrefs();
            assert(prefs.textColor === '#336699', 'Reload custom color from settings file');
        } finally {
            base = originalBase; prefs = originalPrefs;
            fm.removeItemAtPathError($(colorTestDir), null);
        }
        controller.blackText($());
        assert(colorToHex(ui.text.textColor) === '#000000', 'Black preset');
        controller.whiteText($());
        assert(colorToHex(ui.text.textColor) === '#FFFFFF', 'White preset');
        controller.autoText($()); prefs.dark = true; applyStyle();
        assert(prefs.textColor === null && colorToHex(ui.text.textColor) === '#FFFFFF', 'Follow-background reset in dark mode');
        prefs.dark = false; applyStyle();
        assert(colorToHex(ui.text.textColor) === '#000000', 'Follow-background reset in light mode');
        assert(normalizeTextColor('#aBc123') === '#ABC123' && normalizeTextColor('bad-color') === null, 'Validate persisted color format');
        var samplerCheck = $.NSColorSampler.alloc.init;
        assert(Boolean(samplerCheck.respondsToSelector('showSamplerWithSelectionHandler:')), 'Native screen sampler available');
        acceptSampledColor($.NSColor.colorWithSRGBRedGreenBlueAlpha(0.4, 0.6, 0.8, 1));
        assert(prefs.textColor === '#6699CC' && colorToHex(ui.text.textColor) === '#6699CC', 'Screen-sampled color applies to text');
        acceptSampledColor($());
        acceptSampledColor($.NSNull.null);
        assert(prefs.textColor === '#6699CC', 'Cancelling sampler preserves text color');
        changeTextColor(null);
        var textEdits = 0, synchronousSaves = 0;
        var opacityObserver = center.addObserverForNameObjectQueueUsingBlock($.NSTextStorageDidProcessEditingNotification, ui.text.textStorage, $(), function() { textEdits++; });
        applyStyle();
        assert(textEdits > 0, 'Text storage observer detects full style changes');
        textEdits = 0;
        var originalSave = save;
        save = function() { synchronousSaves++; };
        try {
            for (var opacityStep = 0; opacityStep <= 100; opacityStep++) {
                ui.slider.doubleValue = opacityStep / 100;
                controller.opacityChanged(ui.slider);
            }
        } finally {
            save = originalSave;
            center.removeObserver(opacityObserver);
        }
        assert(textEdits === 0, '101 slider events do not edit or restyle the book');
        assert(synchronousSaves === 0, 'Slider events do not synchronously save to disk');
        assert(Number(ui.text.selectedRange.location) === 5 && Number(ui.text.selectedRange.length) === 2, 'Opacity preserves text selection');
        assert(Math.abs(progress() - 0.5) < 0.03, 'Opacity preserves scroll position');
        assert(prefs.opacity === 1 && Number(ui.window.backgroundColor.alphaComponent) === 1, 'Slider final value applied');
        assert(ObjC.unwrap(ui.opacityValue.stringValue) === '100%', 'Percentage display updated');
        changeOpacity(0);
        assert(Number(ui.window.backgroundColor.alphaComponent) === 0 && Number(ui.text.textColor.alphaComponent) === 1, 'Transparent background keeps text opaque');
        changeTextColor('#6699CC');
        var anchorBeforeFont = readingAnchor();
        changeFont(1); assert(Math.abs(readingAnchor() - anchorBeforeFont) <= sample.length * 2, 'Preserve visible text after font change');
        assert(colorToHex(ui.text.textColor) === '#6699CC', 'Typography update preserves sampled text color');
        var anchorBeforeSpacing = readingAnchor();
        changeLineSpacing(24);
        assert(prefs.lineSpacing === 24 && Number(ui.text.defaultParagraphStyle.lineSpacing) === 24, 'Apply custom line spacing');
        assert(Math.abs(readingAnchor() - anchorBeforeSpacing) <= sample.length * 2, 'Preserve visible text after spacing change');
        var typographyApplications = 0, originalTypography = applyTypography;
        applyTypography = function(anchor, selection) { typographyApplications++; originalTypography(anchor, selection); };
        try {
            for (var click = 0; click < 12; click++) queueTypography();
            $.NSRunLoop.currentRunLoop.runUntilDate($.NSDate.dateWithTimeIntervalSinceNow(0.2));
            assert(typographyApplications === 1 && pendingTypography === null, 'Native timer coalesces 12 rapid updates into one typography pass');
        } finally {
            if (typographyTimer !== null) typographyTimer.invalidate;
            typographyTimer = null; pendingTypography = null;
            applyTypography = originalTypography;
        }
        var fixture = '😀开场\n序章\n正文提到第一章，但不是章节标题。\n第一章 起点\n你好，ABC。\n第二章 相逢\n再见，abc。[a.b]\nChapter 3 Home\n尾声\n';
        showBook(fixture, '目录搜索测试', '/test-chapters.txt', 0);
        assert(!chaptersEnabled && chapters.length === 0, 'Chapter recognition off until explicitly enabled');
        assert(!Boolean(ui.chapterList.enabled), 'No automatic chapter scanning on import');
        toggleChapters();
        assert(chapters.length === 5, 'Recognize Chinese, English and prologue headings');
        assert(fixture.slice(chapters[1].index, chapters[1].index + chapters[1].length) === '第一章 起点', 'UTF-16 chapter offsets after emoji');
        ui.chapterList.selectItemAtIndex(3); selectChapter();
        assert(Number(ui.text.selectedRange.location) === fixture.indexOf('第二章'), 'Chapter selection locates text');
        ui.search.stringValue = 'abc'; searchText(1);
        assert(Number(ui.text.selectedRange.location) === fixture.indexOf('ABC'), 'Case-insensitive search selects first result');
        searchText(1);
        assert(Number(ui.text.selectedRange.location) === fixture.indexOf('abc'), 'Find next result');
        searchText(1);
        assert(Number(ui.text.selectedRange.location) === fixture.indexOf('ABC') && searchState.range.wrapped, 'Wrap search at end of book');
        searchText(-1);
        assert(Number(ui.text.selectedRange.location) === fixture.indexOf('abc') && searchState.range.wrapped, 'Wrap backwards search');
        ui.search.stringValue = '[a.b]'; searchText(1);
        assert(Number(ui.text.selectedRange.location) === fixture.indexOf('[a.b]'), 'Search punctuation literally');
        ui.search.stringValue = '不存在的词'; searchText(1);
        assert(searchState.range === null && ObjC.unwrap(ui.searchResult.stringValue) === '未找到', 'No-match state');
        ui.search.stringValue = ''; searchText(1);
        assert(ObjC.unwrap(ui.searchResult.stringValue) === '输入关键词', 'Empty search is safe');
        prefs.compact = true; layout();
        assert(Boolean(ui.search.hidden) && Boolean(ui.chapterList.hidden) && Boolean(ui.spacingSlider.hidden) && Boolean(ui.colorWell.hidden) && Boolean(ui.colorAuto.hidden) && Boolean(ui.sampleColor.hidden), 'New tools hide in compact mode');
        var findEvent = $.NSEvent.keyEventWithTypeLocationModifierFlagsTimestampWindowNumberContextCharactersCharactersIgnoringModifiersIsARepeatKeyCode(10, $.NSMakePoint(0, 0), 0x100000, 0, Number(ui.window.windowNumber), $(), $('f'), $('f'), false, 3);
        assert(Boolean(ui.window.performKeyEquivalent(findEvent)) && !prefs.compact, 'Cmd-F opens search from compact mode');
        showBook('没有章节标题的正文。', '另一本书', '/another.txt', 0);
        assert(!chaptersEnabled && chapters.length === 0 && searchState.range === null, 'New book resets directory and search');
        toggleChapters();
        assert(chapters.length === 0 && !Boolean(ui.chapterList.enabled), 'Book without chapter headings');
        assert(recognizeChapters('第一章 重复\n第一章 重复\n').length === 2, 'Repeated headings retain both locations');
        prefs.compact = false;
        ui.window.setContentSize($.NSMakeSize(480, 640)); layout();
        showBook(Array(500).join('窗口缩放测试，正文应当在拖动时保持原来的换行，松手后再换行。\n'), '缩放测试', '/resize-test.txt', 0.4);
        ui.text.setSelectedRange($.NSMakeRange(5, 2));
        var resizeAnchor = readingAnchor();
        var initialContainerWidth = Number(ui.text.textContainer.containerSize.width);
        controller.windowWillStartLiveResize($());
        for (var resizeStep = 0; resizeStep < 10; resizeStep++) {
            ui.window.setContentSize($.NSMakeSize(500 + resizeStep * 10, 640));
            controller.windowDidResize($());
            assert(liveResizeState.frozen && !Boolean(ui.text.textContainer.widthTracksTextView), 'Width drag freezes text wrapping');
            assert(Number(ui.text.textContainer.containerSize.width) === initialContainerWidth, 'Repeated drag events keep wrapping width unchanged');
        }
        controller.windowDidEndLiveResize($());
        assert(liveResizeState === null && Boolean(ui.text.textContainer.widthTracksTextView), 'Wrapping follows final width after release');
        assert(Number(ui.text.textContainer.containerSize.width) !== initialContainerWidth, 'Final width is applied');
        assert(Math.abs(Number(ui.text.frame.size.width) - Number(ui.scroll.contentSize.width)) < 1, 'Document fits final viewport');
        assert(Number(ui.text.selectedRange.location) === 5 && Number(ui.text.selectedRange.length) === 2, 'Resize preserves selection');
        assert(Math.abs(readingAnchor() - resizeAnchor) < 120, 'Resize preserves current reading paragraph');
        var heightOnlyWidth = Number(ui.root.bounds.size.width);
        controller.windowWillStartLiveResize($());
        ui.window.setContentSize($.NSMakeSize(heightOnlyWidth, 80));
        controller.windowDidResize($());
        assert(!liveResizeState.frozen && Boolean(ui.text.textContainer.widthTracksTextView), 'Height-only drag does not reconfigure wrapping');
        controller.windowDidEndLiveResize($());
        assert(Number(ui.window.minSize.height) === 80 && compactLayout(), 'Allow very short reading windows');
        assert(Boolean(ui.heading.hidden) && Boolean(ui.search.hidden) && !Boolean(ui.compact.hidden), 'Short window automatically hides tools and keeps expand button');
        assert(Number(ui.scroll.frame.size.height) >= 30, 'Short window retains readable viewport');
        toggleCompact();
        assert(!compactLayout() && !Boolean(ui.search.hidden), 'Expand restores sufficient space for controls');
        ui.window.setContentSize($.NSMakeSize(300, 100)); layout();
        assert(compactLayout() && Number(ui.scroll.frame.size.width) > 0, 'Narrow windows use valid compact geometry');
        ui.window.performKeyEquivalent(findEvent);
        assert(!compactLayout() && !Boolean(ui.search.hidden), 'Cmd-F expands small window before focusing search');
        var chapterBody = Array(100).join('方向键阅读测试，正文足够长，用来检查上下滚动与左右切章。\n');
        var navigationBook = '阅读说明\n第一章 开始\n' + chapterBody + '\n第二章 相逢\n' + chapterBody + '\n第三章 结束\n' + chapterBody;
        showBook(navigationBook, '方向键测试', '/arrows.txt', 0);
        ui.window.makeFirstResponder(ui.text);
        function arrowEvent(code, repeat, modifiers) {
            var character = String.fromCharCode(code === 126 ? 0xf700 : code === 125 ? 0xf701 : code === 123 ? 0xf702 : 0xf703);
            return $.NSEvent.keyEventWithTypeLocationModifierFlagsTimestampWindowNumberContextCharactersCharactersIgnoringModifiersIsARepeatKeyCode(10, $.NSMakePoint(0, 0), modifiers === undefined ? 0xa00000 : modifiers, 0, Number(ui.window.windowNumber), $(), $(character), $(character), !!repeat, code);
        }
        ui.window.sendEvent(arrowEvent(124));
        assert(!chaptersEnabled && chapters.length === 0, 'Arrow chapter navigation never enables recognition automatically');
        toggleChapters();
        assert(chapters.length === 3, 'Navigation fixture has three chapters');
        ui.window.sendEvent(arrowEvent(124));
        assert(Number(ui.text.selectedRange.location) === chapters[0].index, 'Right arrow enters first chapter from preface');
        ui.window.sendEvent(arrowEvent(124));
        assert(Number(ui.text.selectedRange.location) === chapters[1].index && Number(ui.chapterList.indexOfSelectedItem) === 2, 'Native right arrow selects next chapter and syncs directory');
        ui.window.sendEvent(arrowEvent(123));
        assert(Number(ui.text.selectedRange.location) === chapters[0].index, 'Native left arrow selects previous chapter');
        ui.window.sendEvent(arrowEvent(123));
        assert(Number(ui.text.selectedRange.location) === chapters[0].index, 'Left arrow stops at first chapter');
        ui.window.sendEvent(arrowEvent(124, true));
        assert(Number(ui.text.selectedRange.location) === chapters[0].index, 'Holding chapter key does not skip chapters');
        var yBeforeDown = Number(ui.scroll.contentView.bounds.origin.y);
        ui.window.sendEvent(arrowEvent(125));
        var yAfterDown = Number(ui.scroll.contentView.bounds.origin.y);
        assert(yAfterDown > yBeforeDown, 'Down arrow scrolls document down');
        ui.window.sendEvent(arrowEvent(126));
        assert(Math.abs(Number(ui.scroll.contentView.bounds.origin.y) - yBeforeDown) < 1, 'Up arrow scrolls document up');
        ui.window.sendEvent(arrowEvent(125, true));
        assert(Number(ui.scroll.contentView.bounds.origin.y) > yBeforeDown, 'Holding vertical key keeps scrolling');
        ui.window.sendEvent(arrowEvent(124));
        assert(Number(ui.text.selectedRange.location) === chapters[1].index, 'Chapter navigation follows reading position after scrolling');
        jumpToChapter(2);
        ui.window.sendEvent(arrowEvent(124));
        assert(Number(ui.text.selectedRange.location) === chapters[2].index, 'Right arrow stops at last chapter');
        assert(!dispatchReadingArrow(arrowEvent(123, false, 0x80000)), 'Modified arrows keep native behavior');
        var beforeEditing = Number(ui.text.selectedRange.location);
        ui.search.stringValue = '查找文字';
        ui.window.makeFirstResponder(ui.search); ui.search.selectText(null);
        assert(!dispatchReadingArrow(arrowEvent(123)) && !dispatchReadingArrow(arrowEvent(125)), 'Search field retains text-editing arrows');
        assert(Number(ui.text.selectedRange.location) === beforeEditing, 'Editing search does not navigate the book');
        ui.window.makeFirstResponder(ui.text);
        ui.scroll.contentView.scrollToPoint($.NSMakePoint(0, 0));
        ui.window.sendEvent(arrowEvent(126));
        assert(Number(ui.scroll.contentView.bounds.origin.y) === 0, 'Up arrow clamps at start of book');
        var formCheck = shortcutSettingsForm(defaultShortcuts());
        assert(JSON.stringify(readShortcutForm(formCheck)) === JSON.stringify(defaultShortcuts()), 'Native settings controls represent defaults');
        formCheck.rows.compact.key.selectItemAtIndex(Number(formCheck.rows.visibility.key.indexOfSelectedItem));
        assert(validateShortcuts(readShortcutForm(formCheck)).length > 0, 'Settings form detects duplicate bindings');
        var customKeys = { visibility: { keyCode: 40, modifiers: 0xc0000 }, compact: { keyCode: 38, modifiers: 0x120000 } };
        applyShortcutSettings(customKeys);
        assert(shortcutAction({keyCode:40, modifierFlags:0xc0000}) === 'visibility' && shortcutAction({keyCode:38, modifierFlags:0x120000}) === 'compact', 'Custom keys replace both actions immediately');
        assert(shortcutAction({keyCode:6, modifierFlags:0x80000}) === '', 'Previous shortcut stops matching after change');
        assert(ObjC.unwrap(ui.visibilityMenu.keyEquivalent) === 'k' && Number(ui.visibilityMenu.keyEquivalentModifierMask) === 0xc0000, 'Menu reflects custom visibility shortcut');
        assert(ObjC.unwrap(ui.compactMenu.keyEquivalent) === 'j' && Number(ui.compactMenu.keyEquivalentModifierMask) === 0x120000, 'Menu reflects custom compact shortcut');
        var newVisibilityCalls = 0;
        shortcutTestSink = function(action) { if (action === 'visibility') newVisibilityCalls++; };
        var newVisibilityEvent = $.NSEvent.keyEventWithTypeLocationModifierFlagsTimestampWindowNumberContextCharactersCharactersIgnoringModifiersIsARepeatKeyCode(10, $.NSMakePoint(0,0), 0xc0000, 0, Number(ui.window.windowNumber), $(), $('k'), $('k'), false, 40);
        ui.window.sendEvent(newVisibilityEvent);
        assert(newVisibilityCalls === 1, 'Native window dispatches new shortcut');
        shortcutSettingsOpen = true;
        assert(!dispatchShortcut(newVisibilityEvent), 'Shortcuts pause while editing settings');
        shortcutSettingsOpen = false; shortcutTestSink = null;
        var newCompactEvent = $.NSEvent.keyEventWithTypeLocationModifierFlagsTimestampWindowNumberContextCharactersCharactersIgnoringModifiersIsARepeatKeyCode(10, $.NSMakePoint(0,0), 0x120000, 0, Number(ui.window.windowNumber), $(), $('J'), $('j'), false, 38);
        ui.window.sendEvent(newCompactEvent); assert(prefs.compact, 'New compact shortcut works natively');
        ui.window.sendEvent(newCompactEvent); assert(!prefs.compact, 'New compact shortcut expands natively');
        var shortcutBase = base, shortcutPrefs = prefs;
        var shortcutTestDir = ObjC.unwrap($.NSTemporaryDirectory()) + 'moyu-reader-shortcut-check';
        fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError($(shortcutTestDir), true, $.NSDictionary.dictionary, null);
        try {
            writeText(JSON.stringify(prefs), shortcutTestDir + '/settings.json'); base = shortcutTestDir; loadPrefs();
            assert(JSON.stringify(prefs.shortcuts) === JSON.stringify(customKeys), 'Reload customized shortcuts from settings');
            writeText(JSON.stringify({shortcuts:{visibility:{keyCode:6, modifiers:0},compact:{keyCode:7, modifiers:0}}}), shortcutTestDir + '/settings.json');
            loadPrefs(); assert(JSON.stringify(prefs.shortcuts) === JSON.stringify(defaultShortcuts()), 'Invalid saved bindings recover to defaults');
        } finally { base = shortcutBase; prefs = shortcutPrefs; fm.removeItemAtPathError($(shortcutTestDir), null); }
        var rejected = false;
        try { applyShortcutSettings({visibility:customKeys.visibility,compact:customKeys.visibility}); } catch(e) { rejected = true; }
        assert(rejected && JSON.stringify(prefs.shortcuts) === JSON.stringify(customKeys), 'Invalid changes cannot overwrite active shortcuts');
        assert(validateShortcuts({visibility:{keyCode:12,modifiers:0x100000},compact:customKeys.compact}).length > 0, 'Preserve reserved Cmd-Q');
        var functionKeys = {visibility:{keyCode:122,modifiers:0x80000},compact:{keyCode:120,modifiers:0x40000}};
        assert(validateShortcuts(functionKeys) === '' && formatShortcut(functionKeys.visibility) === '⌥F1', 'Function-key choices supported');
        assert(formatShortcut(customKeys.visibility) === '⌃⌥K', 'Shortcut labels match modifier choices');
        applyShortcutSettings(defaultShortcuts());
        assert(shortcutAction({keyCode:6, modifierFlags:0x80000}) === 'visibility' && ObjC.unwrap(ui.visibilityMenu.keyEquivalent) === 'z', 'Restore default shortcuts updates handlers and menus');
        return 'PASS: editable shortcut controls, live native key changes, persistence, conflict rejection, defaults, function keys, settings isolation, arrows, resizing, typography, colors and reader checks';
    }
}
function idle() { refreshShortcut(); save(); return 2; }
function quit() { save(); }
